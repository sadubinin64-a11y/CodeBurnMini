package local.codeburn.mini;
public class WindowValueTest {
 static void eq(Object want,Object got){if(!want.equals(got))throw new AssertionError("Expected "+want+", got "+got);}
 public static void main(String[] args){
  eq(100,WindowValue.remaining(0));eq(0,WindowValue.remaining(100));eq(98,WindowValue.remaining(2));eq(75,WindowValue.remaining("25.4"));
  for(Object v:new Object[]{"", " ","NaN","Infinity","bad",-1,101,true,new Object()})eq(-1,WindowValue.remaining(v));eq(-1,WindowValue.remaining(null));
  eq("week",WindowValue.name(604800));eq("hour",WindowValue.name(18000));eq("",WindowValue.name(86400));
  System.out.println("17 checks passed: percentages, missing/malformed values, window durations");
 }
}

