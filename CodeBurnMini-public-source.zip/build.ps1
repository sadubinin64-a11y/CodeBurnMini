param(
 [Parameter(Mandatory=$true)][string]$JavaHome,
 [Parameter(Mandatory=$true)][string]$SdkRoot,
 [Parameter(Mandatory=$true)][string]$KeyStore,
 [Parameter(Mandatory=$true)][string]$PasswordFile,
 [string]$KeyAlias='codeburn-release'
)
$ErrorActionPreference='Stop'
$env:JAVA_HOME=$JavaHome
$root=Join-Path $PSScriptRoot 'android'
$build=Join-Path $PSScriptRoot '.local-build'
$bt=Join-Path $SdkRoot 'build-tools\35.0.0'
$platform=Join-Path $SdkRoot 'platforms\android-35\android.jar'
New-Item -ItemType Directory -Force "$build\classes","$build\dex","$build\gen","$build\tests" | Out-Null
function Run([string]$exe,[string[]]$argsList){ & $exe @argsList; if($LASTEXITCODE -ne 0){throw "Failed: $exe"} }
Run "$JavaHome\bin\javac.exe" @('-encoding','UTF-8','--release','8','-d',"$build\tests","$root\src\local\codexlimits\WindowValue.java","$PSScriptRoot\tests\WindowValueTest.java")
Run "$JavaHome\bin\java.exe" @('-cp',"$build\tests",'local.codeburn.mini.WindowValueTest')
Run "$bt\aapt2.exe" @('compile','--dir',"$root\res",'-o',"$build\resources.zip")
Run "$bt\aapt2.exe" @('link','-o',"$build\unsigned.apk",'-I',$platform,'--manifest',"$root\AndroidManifest.xml",'--java',"$build\gen",'-R',"$build\resources.zip")
$sources=@(Get-ChildItem "$root\src","$build\gen" -Recurse -Filter '*.java' | ForEach-Object FullName)
Run "$JavaHome\bin\javac.exe" (@('-encoding','UTF-8','--release','8','-classpath',$platform,'-d',"$build\classes")+$sources)
Run "$JavaHome\bin\jar.exe" @('cf',"$build\classes.jar",'-C',"$build\classes",'.')
Run "$bt\d8.bat" @('--min-api','26','--lib',$platform,'--output',"$build\dex","$build\classes.jar")
Run "$JavaHome\bin\jar.exe" @('uf',"$build\unsigned.apk",'-C',"$build\dex",'classes.dex')
Run "$bt\zipalign.exe" @('-f','4',"$build\unsigned.apk","$build\aligned.apk")
Run "$bt\apksigner.bat" @('sign','--ks',$KeyStore,'--ks-key-alias',$KeyAlias,'--ks-pass',"file:$PasswordFile",'--out',"$PSScriptRoot\CodeBurnMini-0.5.apk","$build\aligned.apk")
Run "$bt\apksigner.bat" @('verify','--verbose','--print-certs',"$PSScriptRoot\CodeBurnMini-0.5.apk")
(Get-FileHash -LiteralPath "$PSScriptRoot\CodeBurnMini-0.5.apk" -Algorithm SHA256).Hash.ToLower()+'  CodeBurnMini-0.5.apk' | Set-Content -LiteralPath "$PSScriptRoot\CodeBurnMini-0.5.apk.sha256" -Encoding ascii
