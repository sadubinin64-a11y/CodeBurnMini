package local.codeburn.mini;
import android.app.*;
import android.app.job.JobScheduler;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.widget.*;
import org.json.JSONObject;
public class MainActivity extends Activity {
 static volatile String message="",code="";static volatile boolean busy=false;
 volatile boolean hasLogin=false,authChecked=false; TextView status,device,values,session,help;Button login,browser,cancel,refresh;Handler handler=new Handler();
 final Runnable redraw=new Runnable(){public void run(){paint();handler.postDelayed(this,1000);}};
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(8192,8192);
  ScrollView scroll=new ScrollView(this);LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(24,60,24,32);scroll.addView(l);setContentView(scroll);
  TextView title=new TextView(this);title.setText("CodeBurn Mini · 0.5");title.setTextSize(24);l.addView(title);
  session=new TextView(this);l.addView(session); help=new TextView(this);help.setText("1. Нажмите «Войти через ChatGPT».\n2. Откройте страницу входа и введите показанный код.\n3. Подтвердите вход на сайте OpenAI и вернитесь сюда.\n\nНеофициальное приложение. Экспериментальный вход по коду Codex; на некоторых аккаунтах требуется разрешить его в настройках безопасности ChatGPT. ПК не нужен.");l.addView(help);
  device=new TextView(this);device.setTextSize(28);device.setTextIsSelectable(true);l.addView(device);
  login=button(l,"Войти через ChatGPT");login.setOnClickListener(v->startLogin());
  browser=button(l,"Открыть страницу входа OpenAI");browser.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://auth.openai.com/codex/device")));}catch(Exception e){message="Откройте в браузере https://auth.openai.com/codex/device";}});
  cancel=button(l,"Отменить вход");cancel.setOnClickListener(v->{Client.generation++;busy=false;code="";message="Вход отменён";});
  refresh=button(l,"Обновить лимиты");refresh.setOnClickListener(v->update());
  Button logout=button(l,"Выйти и удалить данные");logout.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Удалить вход и показатели с этого телефона?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{Client.generation++;busy=true;code="";message="Удаляем вход…";Context app=getApplicationContext();new Thread(()->{Client.logout(app);hasLogin=false;authChecked=true;((JobScheduler)app.getSystemService(JOB_SCHEDULER_SERVICE)).cancel(25);message="Вход и данные удалены";busy=false;}).start();}).show());
  values=new TextView(this);l.addView(values);status=new TextView(this);l.addView(status);
  TextView foot=new TextView(this);foot.setText("Виджет добавляется через меню рабочего стола → Виджеты. Фоновая проверка — примерно раз в 30 минут, Android может её откладывать. Нажатие на виджет открывает это приложение. Вход хранится зашифрованным средствами Android.");l.addView(foot);
 }
 Button button(LinearLayout l,String text){Button b=new Button(this);b.setText(text);l.addView(b);return b;}
 void startLogin(){if(busy)return;busy=true;message="Получаем одноразовый код…";code="";final int version=++Client.generation;final Context app=getApplicationContext();
  new Thread(()->{try{JSONObject d=Client.start();if(version!=Client.generation)return;code=d.optString("user_code",d.optString("usercode"));if(code.isEmpty())throw new java.io.IOException("Сервер не вернул код входа");message="Откройте страницу OpenAI, введите этот код, подтвердите вход и вернитесь. Код действует 15 минут.";
   long deadline=SystemClock.elapsedRealtime()+15*60*1000;long interval=Math.max(5,Math.min(60,d.optLong("interval",5)))*1000;
   while(version==Client.generation&&SystemClock.elapsedRealtime()<deadline){if(Client.poll(app,d,version)){if(version!=Client.generation)return;code="";hasLogin=true;authChecked=true;message="Вход выполнен. Получаем лимиты…";RefreshJob.schedule(app);message=Client.update(app);return;}Thread.sleep(interval);}
   if(version==Client.generation){message="Время входа истекло. Нажмите «Войти через ChatGPT» ещё раз.";code="";}
  }catch(Exception e){if(version==Client.generation){message=Client.error(e);code="";}}finally{if(version==Client.generation)busy=false;}}).start();
 }
 void update(){if(busy)return;busy=true;message="Получаем лимиты…";Context app=getApplicationContext();new Thread(()->{try{message=Client.update(app);RefreshJob.schedule(app);}catch(Exception e){message=Client.error(e);app.getSharedPreferences("limits",0).edit().putString("error",message).commit();LimitsWidget.render(app);}finally{busy=false;}}).start();}
 static void text(TextView view,String value){if(!view.getText().toString().equals(value))view.setText(value);}
 void paint(){if(status==null)return;text(device,code);browser.setVisibility(code.isEmpty()?8:0);cancel.setVisibility(code.isEmpty()?8:0);login.setEnabled(!busy && authChecked);refresh.setEnabled(!busy && authChecked);text(login,hasLogin?"Войти заново / сменить аккаунт":"Войти через ChatGPT");help.setVisibility(hasLogin?8:0);text(session,!authChecked?"Проверяем сохранённый вход…":hasLogin?"Вход сохранён на телефоне. Повторный код обычно не нужен.":"Сохранённый вход не найден.");text(status,message.isEmpty()?getSharedPreferences("limits",0).getString("error",""):message);
  SharedPreferences p=getSharedPreferences("limits",0);String text="";for(String k:new String[]{"hour","week"}){int n=p.getInt(k,-1);text+=(k.equals("hour")?"5 часов":"Неделя")+": "+(n<0?"нет данных":("осталось "+n+"%"))+"\n";long reset=p.getLong(k+"Reset",0);if(reset>0)text+="Сброс: "+java.text.DateFormat.getDateTimeInstance(3,3).format(new java.util.Date(reset*1000))+"\n";}long at=p.getLong("updated",0);if(at>0)text+="Обновлено: "+java.text.DateFormat.getDateTimeInstance(3,3).format(new java.util.Date(at));text(values,text);
 }
 protected void onResume(){super.onResume();handler.post(redraw);
  final Context app=getApplicationContext();
  new Thread(()->{
   try {
    boolean found;
    synchronized(Client.LOCK){found=Vault.read(app)!=null;}
    hasLogin=found;authChecked=true;
    if(found){RefreshJob.schedule(app);runOnUiThread(()->{if(!isFinishing() && !isDestroyed() && !busy)update();});}
   }catch(Exception e){authChecked=true;message=Client.error(e);}
  }).start();
 }
 protected void onPause(){handler.removeCallbacks(redraw);super.onPause();}
}





