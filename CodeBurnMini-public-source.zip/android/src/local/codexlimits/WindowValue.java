package local.codeburn.mini;
final class WindowValue {
 static int remaining(Object value){
  if(!(value instanceof Number)&&!(value instanceof String))return -1;
  try{String s=value.toString().trim();if(s.isEmpty())return -1;double n=Double.parseDouble(s);return Double.isNaN(n)||Double.isInfinite(n)||n<0||n>100?-1:(int)Math.round(100-n);}catch(Exception e){return -1;}
 }
 static String name(long seconds){return seconds==18000?"hour":seconds==604800?"week":"";}
}

