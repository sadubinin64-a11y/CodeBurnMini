package local.codeburn.mini;
import android.content.*;
import android.os.SystemClock;
import android.util.Base64;
import java.net.*;
import java.io.*;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;
final class Client {
 static final String AUTH="https://auth.openai.com", ID="app_EMoamEEZ73f0CkXaXp7hrann";
 static final Object LOCK=new Object();
 static volatile int generation=0;
 static final class Reply {int code;JSONObject body;long retry;}
 static Reply request(String url,JSONObject body,boolean form,JSONObject login) throws Exception {
  HttpsURLConnection c=(HttpsURLConnection)new URL(url).openConnection();
  c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","CodeBurn");
  try {
   if(login!=null){c.setRequestProperty("Authorization","Bearer "+login.getString("access_token"));String a=login.optString("account_id");if(!a.isEmpty())c.setRequestProperty("ChatGPT-Account-Id",a);}
   if(body!=null){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type",form?"application/x-www-form-urlencoded":"application/json");String s=body.toString();if(form){StringBuilder b=new StringBuilder();java.util.Iterator<String> it=body.keys();while(it.hasNext()){String k=it.next();if(b.length()>0)b.append('&');b.append(URLEncoder.encode(k,"UTF-8")).append('=').append(URLEncoder.encode(body.getString(k),"UTF-8"));}s=b.toString();}try(OutputStream o=c.getOutputStream()){o.write(s.getBytes("UTF-8"));}}
   Reply r=new Reply();r.code=c.getResponseCode();r.body=new JSONObject();String retry=c.getHeaderField("Retry-After");try{r.retry=Math.max(60,Long.parseLong(retry));}catch(Exception ignored){r.retry=300;}
   InputStream stream=r.code<400?c.getInputStream():c.getErrorStream();if(stream!=null)try(InputStream in=stream){ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){o.write(b,0,n);if(o.size()>1048576)throw new IOException("Слишком большой ответ");}try{r.body=new JSONObject(o.toString("UTF-8"));}catch(JSONException e){if(r.code<400)throw new IOException("Сервер вернул неожиданный ответ");}}
   return r;
  }finally{c.disconnect();}
 }
 static void require(Reply r,String action) throws IOException {if(r.code<200||r.code>=300)throw new IOException(action+": HTTP "+r.code+(r.code==403?". Сервер отказал в доступе; это не обязательно потеря входа.":""));}
 static JSONObject start() throws Exception {Reply r=request(AUTH+"/api/accounts/deviceauth/usercode",new JSONObject().put("client_id",ID),false,null);require(r,"Не удалось получить код");return r.body;}
 static boolean poll(Context c,JSONObject device,int version) throws Exception {
  Reply r=request(AUTH+"/api/accounts/deviceauth/token",new JSONObject().put("device_auth_id",device.getString("device_auth_id")).put("user_code",device.optString("user_code",device.optString("usercode"))),false,null);
  if(r.code==403||r.code==404)return false;require(r,"Проверка входа");
  Reply t=request(AUTH+"/oauth/token",new JSONObject().put("grant_type","authorization_code").put("client_id",ID).put("code",r.body.getString("authorization_code")).put("code_verifier",r.body.getString("code_verifier")).put("redirect_uri",AUTH+"/deviceauth/callback"),true,null);require(t,"Обмен кода");
  synchronized(LOCK){if(version!=generation)return false;saveTokens(c,t.body,null);}return true;
 }
 static void saveTokens(Context c,JSONObject next,JSONObject old) throws Exception {
  if(next.optString("access_token").isEmpty())throw new IOException("Сервер не вернул токен входа");
  if(old!=null){if(next.optString("refresh_token").isEmpty())next.put("refresh_token",old.optString("refresh_token"));next.put("account_id",old.optString("account_id"));}
  for(String k:new String[]{"id_token","access_token"})try{JSONObject claims=new JSONObject(new String(Base64.decode(next.getString(k).split("\\.")[1],Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING),"UTF-8"));JSONObject auth=claims.optJSONObject("https://api.openai.com/auth");if(auth!=null&&!auth.optString("chatgpt_account_id").isEmpty())next.put("account_id",auth.getString("chatgpt_account_id"));}catch(Exception ignored){}
  next.put("expires",System.currentTimeMillis()+Math.max(60,next.optLong("expires_in",3600))*1000);Vault.save(c,next);if(old==null)c.getSharedPreferences("limits",0).edit().clear().commit();
 }
 static JSONObject refresh(Context c,JSONObject old) throws Exception {
  if(old.optString("refresh_token").isEmpty())throw new IOException("Войдите через ChatGPT заново");
  Reply r=request(AUTH+"/oauth/token",new JSONObject().put("client_id",ID).put("grant_type","refresh_token").put("refresh_token",old.getString("refresh_token")),true,null);require(r,"Обновление входа");saveTokens(c,r.body,old);return Vault.read(c);
 }
 static String update(Context c) throws Exception {synchronized(LOCK){
  SharedPreferences p=c.getSharedPreferences("limits",0);if(p.getLong("retry",0)>System.currentTimeMillis())throw new IOException("Сервер попросил подождать. Повторите позже.");
  JSONObject login;try{login=Vault.read(c);}catch(Exception e){throw new IOException("Не удалось открыть сохранённый вход ("+e.getClass().getSimpleName()+"). Данные не удалены.");}if(login==null)throw new IOException("Нажмите «Войти через ChatGPT»");
  if(login.optLong("expires",0)<System.currentTimeMillis()+60000)login=refresh(c,login);
  Reply r=request("https://chatgpt.com/backend-api/wham/usage",null,false,login);
  if(r.code==401){login=refresh(c,login);r=request("https://chatgpt.com/backend-api/wham/usage",null,false,login);}
  if(r.code==429){p.edit().putLong("retry",System.currentTimeMillis()+Math.min(r.retry,86400)*1000).commit();throw new IOException("Слишком частые запросы. Повторите позже.");}require(r,"Получение лимитов");
  JSONObject rate=r.body.optJSONObject("rate_limit");int h=-1,w=-1;long hr=0,wr=0;
  if(rate!=null)for(String key:new String[]{"primary_window","secondary_window"}){JSONObject x=rate.optJSONObject(key);if(x==null||x.isNull("used_percent")||x.optString("used_percent").trim().isEmpty())continue;int remaining=WindowValue.remaining(x.opt("used_percent"));if(remaining<0)continue;long sec=x.optLong("limit_window_seconds",-1),reset=x.optLong("reset_at",0);if(sec==18000){h=remaining;hr=reset;}if(sec==604800){w=remaining;wr=reset;}}
  if(h<0&&w<0)throw new IOException("В ответе нет окон 5 часов и неделя. Возможно, у тарифа другой тип лимита.");
  p.edit().putInt("hour",h).putInt("week",w).putLong("hourReset",hr).putLong("weekReset",wr).putLong("updated",System.currentTimeMillis()).putString("error","").remove("retry").commit();LimitsWidget.render(c);return "Лимиты обновлены напрямую от ChatGPT";
 }}
 static void logout(Context c){synchronized(LOCK){generation++;Vault.clear(c);c.getSharedPreferences("limits",0).edit().clear().commit();}LimitsWidget.render(c);}
 static String error(Exception e){return e instanceof IOException?e.getMessage():"Не удалось подключиться. Проверьте интернет и попробуйте снова.";}
}



