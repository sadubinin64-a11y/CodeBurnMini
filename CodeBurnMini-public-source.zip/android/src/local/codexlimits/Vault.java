package local.codeburn.mini;
import android.content.Context;
import android.security.keystore.*;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;
final class Vault {
 private static javax.crypto.SecretKey key() throws Exception {
  KeyStore k=KeyStore.getInstance("AndroidKeyStore");k.load(null);
  if(!k.containsAlias("codex-login")){KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder("codex-login",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());g.generateKey();}
  return (javax.crypto.SecretKey)k.getKey("codex-login",null);
 }
 static void save(Context c,JSONObject data) throws Exception {
  Cipher x=Cipher.getInstance("AES/GCM/NoPadding");x.init(Cipher.ENCRYPT_MODE,key());
  String value=Base64.encodeToString(x.getIV(),2)+":"+Base64.encodeToString(x.doFinal(data.toString().getBytes("UTF-8")),2);
  if(!c.getSharedPreferences("vault",0).edit().putString("login",value).commit())throw new java.io.IOException("Не удалось сохранить вход");
 }
 static JSONObject read(Context c) throws Exception {
  String s=c.getSharedPreferences("vault",0).getString("login","");if(s.isEmpty())return null;
  String[] a=s.split(":");Cipher x=Cipher.getInstance("AES/GCM/NoPadding");x.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(a[0],2)));
  return new JSONObject(new String(x.doFinal(Base64.decode(a[1],2)),"UTF-8"));
 }
 static void clear(Context c){c.getSharedPreferences("vault",0).edit().clear().commit();}
}

