package local.codeburn.mini;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.Date;
public class LimitsWidget extends AppWidgetProvider {
 public void onUpdate(Context c, AppWidgetManager m, int[] ids) { render(c); RefreshJob.schedule(c); }
 static void render(Context c) {
  AppWidgetManager m=AppWidgetManager.getInstance(c);
  SharedPreferences p=c.getSharedPreferences("limits",0);
  for(int id:m.getAppWidgetIds(new ComponentName(c,LimitsWidget.class))) {
   RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
   row(v,p,"hour",R.id.hour,R.id.hourBar,"5 часов"); row(v,p,"week",R.id.week,R.id.weekBar,"Неделя");
   long time=p.getLong("updated",0); String error=p.getString("error","");
   v.setTextViewText(R.id.status,!error.isEmpty()?error+" · нажмите":time==0?"Нет данных · нажмите для подключения":"Снимок: "+DateFormat.getDateTimeInstance(3,3).format(new Date(time))+(System.currentTimeMillis()-time>3600000?" · устарело":" · нажмите обновить"));
   v.setOnClickPendingIntent(R.id.status,PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT));
   m.updateAppWidget(id,v);
  }
 }
 static void row(RemoteViews v,SharedPreferences p,String key,int label,int bar,String name) {
  int value=p.getInt(key,-1);
  v.setTextViewText(label,name+(value<0?" · нет данных":" · осталось "+value+"%"));
    long reset=p.getLong(key+"Reset",0);
  String suffix=reset>0?"Сброс: "+DateFormat.getDateTimeInstance(3,3).format(new Date(reset*1000)):"Время сброса не получено";
  if(reset>0 && reset*1000<=System.currentTimeMillis())suffix="Срок снимка истёк · обновите";
  v.setTextViewText(key.equals("hour")?R.id.hourReset:R.id.weekReset,suffix);
  v.setProgressBar(bar,100,Math.max(0,value),false);
  v.setViewVisibility(bar,value<0?android.view.View.INVISIBLE:android.view.View.VISIBLE);
 }
}



