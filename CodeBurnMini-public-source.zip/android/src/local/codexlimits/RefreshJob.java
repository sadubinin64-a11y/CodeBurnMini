package local.codeburn.mini;
import android.app.job.*;
import android.content.*;
public class RefreshJob extends JobService {
 public static void schedule(Context c){JobScheduler s=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);s.schedule(new JobInfo.Builder(25,new ComponentName(c,RefreshJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(30*60*1000).setPersisted(true).build());}
 public boolean onStartJob(JobParameters p){new Thread(()->{try{Client.update(this);}catch(Exception e){getSharedPreferences("limits",0).edit().putString("error",Client.error(e)).commit();LimitsWidget.render(this);}finally{jobFinished(p,false);}}).start();return true;}
 public boolean onStopJob(JobParameters p){return true;}
}

